ADMINPRO PRO — PROJETO AMPLIADO

Esta versão mantém o site anterior e adiciona:
- Área de recursos da plataforma
- Área do aluno (estrutura preparada)
- Área de aulas (estrutura preparada)
- Certificados (estrutura preparada)
- Carrinho e pagamentos (estrutura preparada)
- Indicadores e visão administrativa
- Tabela de cursos
- Roadmap do projeto
- Visual responsivo para celular e computador

Para virar uma plataforma real, ainda será necessário backend para login,
banco de dados, pagamentos, certificados e armazenamento de aulas.
